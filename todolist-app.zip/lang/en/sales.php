<?php

return [
    'date_passed' => 'The date has passed.',
];
