<?php

return [
    'company_group' => [
        'not_found' => 'Company Group (:code) not found for email (:email)'
    ],
    'company_sbu' => [
        'not_found' => 'Company SBU (:code) not found for email (:emaiL)'
    ],
    'not_found' => ':data not found!',

    'webhook_attribute_not_found' => 'ATTRIBUTE not found in the given TARGET.',
    'webhook_data_not_found' => 'Data not found with ATTRIBUTE = QUERY in the given TARGET.',
];
