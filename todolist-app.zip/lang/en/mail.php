<?php

return [
    'otp_send' => [
        'subject' => 'New OTP Request'
    ],
    'login_otp_send' => [
        'subject' => 'New Login Alert'
    ],
    'profile_otp_send' => [
        'subject' => 'Profile Verification Alert'
    ],
    'forgot_password_link_send' => [
        'subject' => 'Forgot Password Alert'
    ]
];
