<?php

return [
    'server_error' => 'Server error.',
    'bad_request' => 'Bad request!',
    'mail_error' => 'Mail service unavailable.',
    'ok' => 'OK.',
    'invalid_hash' => 'Invalid hash.',
    'not_found' => 'Not found.',
    'invalid_request' => 'Invalid request.',
    'unauthorized' => 'Unauthenticated.',
];
