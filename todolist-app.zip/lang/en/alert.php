<?php

return [
    'profile_verification_success' => 'Profile verification success!',
    'entity_verification_success' => 'Entity verification success!',
    'old_password_incorrect' => 'Old password is incorrect.',
    'profile_updated' => 'Profile updated.',
];
