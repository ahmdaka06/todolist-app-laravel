<?php

return [
    'profile_verification_success' => 'Profile verification success!',
    'entity_verification_success' => 'Entity verification success!',
];
